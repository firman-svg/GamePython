import random
import time
import sys
import os

def clear_screen():
    """Bersihkan layar terminal"""
    os.system('cls' if os.name == 'nt' else 'clear')

def typing_effect(text, delay=0.03):
    """Efek mengetik yang lebih realistis dengan variasi kecepatan"""
    for i, char in enumerate(text):
        sys.stdout.write(char)
        sys.stdout.flush()
        if char in '.,!?':
            time.sleep(delay * 8)
        elif char == ' ':
            time.sleep(delay * 2)
        elif char in 'aeiou':
            time.sleep(delay * random.uniform(0.8, 1.2))
        else:
            time.sleep(delay * random.uniform(0.9, 1.1))
    print()

def loading_animation(text, duration=2):
    """Animasi loading"""
    for _ in range(duration):
        for i in range(4):
            print(f"\r{text}{'.' * i}    ", end="", flush=True)
            time.sleep(0.5)
    print(f"\r{text}... Done!")

def dialog(nama, teks, emosi="neutral"):
    """Format dialog karakter"""
    emote_map = {
        "happy": "😊",
        "sad": "😢",
        "angry": "😠",
        "excited": "🤩",
        "worried": "😟",
        "surprised": "😲",
        "sleepy": "😴",
        "thinking": "🤔",
        "confused": "😕",
        "friendly": "🙂",
        "firm": "😐",
        "strict": "😑",
        "proud": "😎",
        "impressed": "👍",
        "nervous": "😬",
        "polite": "礼貌",
        "caring": "🤗",
        "supportive": "💪",
        "wise": "🎓",
        "practical": "🔧",
        "passionate": "❤️",
        "curious": "👀",
        "amused": "😄",
        "frustrated": "😤",
        "logical": "🧠",
        "excited": "🎉",
        "disappointed": "😞",
        "suspicious": "🤨",
        "cute": "🥺",
        "vulnerable": "💔",
        "regretful": "😔",
        "helpless": "🤷",
        "grateful": "🙏",
        "inspiring": "✨",
        "reflective": "💭",
        "desperate": " desperation",
        "intimidating": " intimidating",
        "daunting": " daunting",
        "formidable": " formidable",
    }
    emote = emote_map.get(emosi, "💬")
    print(f"{emote} [{nama}]: {teks}")

class Karakter:
    """Kelas untuk karakter-karakter dalam game"""
    def __init__(self, nama, emoji, kepribadian):
        self.nama = nama
        self.emoji = emoji
        self.kepribadian = kepribadian
        self.hubungan = 50
        self.dialog_history = []

class StudentLife:
    def __init__(self):
        # Stats
        self.nama_pemain = ""
        self.uang = 100000  # Uang jajan awal
        self.tabungan = 0
        self.utang = 0
        self.nilai = 70
        self.sanity = 80
        self.hunger = 70
        self.happiness = 70
        self.social = 70
        self.paketan = 5  # Jumlah paket data

        # Stats tambahan yang mungkin hilang
        self.hutang_teman = 0

        # Status harian
        self.hari = 1
        self.game_over = False
        self.game_over_reason = ""

        # Karakter
        self.rina = Karakter("Rina", "👩‍💼", "bijak, pendengar yang baik, rajin menabung")
        self.doni = Karakter("Doni", "👨‍💼", "suka jajan, mudah dipengaruhi, baik hati")
        self.bu_sari = Karakter("Bu Sari", "👩‍🏫", "pembimbing, sabar, menginspirasi")

        # Flags Cerita
        self.story_flags = {
            'bertemu_rina': False,
            'bertemu_doni': False,
            'pelajaran_utang': False,
            'belajar_menabung': False,
            'krisis_pertama': False,
            'midpoint_achievement': False,
            'family_support': False,
            'budget_challenge_success': False,
            'debt_paid': False,
            'financial_freedom': False,
            'final_exam': False,
            'debt_free': False,
            'save_master': False,
            'budget_challenge': False,
            'family_dinner': False,
            'money_lost': False,
        }

        # Riwayat utang
        self.utang_masuk = []  # [(pemberi, jumlah, jatuh_tempo)]
        self.utang_keluar = []  # [(penerima, jumlah, jatuh_tempo)]

        # PR harian
        self.pr_pelajaran = ""
        self.pr_beres = True  # Default True agar tidak langsung ada PR di hari 1

        # Pencapaian
        self.achievements = []

        # Jadwal Hari
        self.jadwal = {
            1: "Senin - Hari Baru",
            2: "Selasa - Hari Biasa",
            3: "Rabu - Tengah Pekan",
            4: "Kamis - Hampir Jumat",
            5: "Jumat - Akhir Pekan",
            6: "Sabtu - Libur",
            7: "Minggu - Libur"
        }

        # Flag untuk mencegah prolog berulang
        self.prolog_ditampilkan = False

    def clamp_stat(self, value, min_val=0, max_val=100):
        """Batasi nilai stat"""
        return max(min_val, min(max_val, value))

    def apply_overflow_effects(self):
        """Berikan bonus jika stat mencapai maksimal"""
        if self.happiness >= 95:
            sanity_bonus = random.randint(5, 10)
            self.sanity = self.clamp_stat(self.sanity + sanity_bonus)
            typing_effect(f"✨ Kamu sangat bahagia! +{sanity_bonus} sanity bonus!", 0.03)
            time.sleep(0.5)
        if self.sanity >= 95:
            nilai_bonus = random.randint(1, 3)
            self.nilai += nilai_bonus
            typing_effect(f"✨ Pikiran jernih! +{nilai_bonus} nilai bonus!", 0.03)
            time.sleep(0.5)
        if self.social >= 95:
            happiness_bonus = random.randint(5, 10)
            self.happiness = self.clamp_stat(self.happiness + happiness_bonus)
            typing_effect(f"✨ Sosialis ulung! +{happiness_bonus} happiness bonus!", 0.03)
            time.sleep(0.5)

    def add_achievement(self, name):
        """Tambahkan pencapaian jika belum ada"""
        if name not in self.achievements:
            self.achievements.append(name)
            typing_effect(f"🏆 PENCAPAIAN: {name}!", 0.04)

    def setup_karakter(self):
        self.story_intro()

    def story_intro(self):
        """Chapter 1: Hari Pertama - HANYA DIPANGGIL SEKALI"""
        if self.prolog_ditampilkan:
            return
            
        clear_screen()
        print("=" * 60)
        typing_effect("🎓 STUDENT LIFE: JOURNEY TO FINANCIAL WISDOM 🎓", 0.05)
        print("=" * 60)
        print()
        typing_effect("📖 PROLOG:", 0.05)
        time.sleep(0.5)
        print()
        typing_effect("Di era digital yang serba cepat ini, banyak remaja yang...", 0.03)
        typing_effect("...kesulitan mengatur keuangan mereka.", 0.03)
        print()
        typing_effect("Tergoda oleh diskon flash sale, FOMO dengan tren terbaru,", 0.03)
        typing_effect("dan tekanan untuk selalu terlihat 'happening' di sosial media.", 0.03)
        print()
        typing_effect("Kamu adalah seorang pelajar SMA yang baru saja mendapatkan", 0.03)
        typing_effect("uang jajan bulanan. Bagaimana kamu akan mengelolanya?", 0.03)
        print()
        time.sleep(2)

        self.nama_pemain = input("Masukkan namamu: ").strip().title()
        if not self.nama_pemain:
            self.nama_pemain = "Anonim"
        print()
        typing_effect(f"Selamat datang, {self.nama_pemain}!", 0.04)
        print()
        time.sleep(1.5)
        input("Tekan ENTER untuk memulai perjalananmu...")
        
        self.prolog_ditampilkan = True

    def tampilkan_status(self):
        clear_screen()
        print("=" * 60)
        typing_effect(f"📅 HARI {self.hari} - {self.nama_pemain}", 0.04)
        print("=" * 60)
        print(f"💰 Uang Jajan: Rp{self.uang:,}")
        print(f"💎 Tabungan: Rp{self.tabungan:,}")
        print(f"💳 Utang: Rp{self.utang:,}")
        print(f"🤝 Piutang: Rp{self.hutang_teman:,}")
        print(f"📊 Hari ke-{self.hari}/30")
        print(f"📊 Nilai: {self.nilai}")
        print(f"🧠 Sanity: {self.sanity}")
        print(f"🍔 Hunger: {self.hunger}")
        print(f"😊 Happiness: {self.happiness}")
        print(f"👥 Social: {self.social}")
        print(f"📱 Paketan: {self.paketan}")
        print("-" * 60)

    def tampilkan_status_singkat(self):
        """Tampilkan status singkat untuk kegiatan"""
        print("=" * 40)
        print("📊 STATUS SEKARANG:")
        print(f"💰 Uang: Rp{self.uang:,} | 💎 Tabungan: Rp{self.tabungan:,}")
        print(f"📚 Nilai: {self.nilai} | 🧠 Sanity: {self.sanity}")
        print(f"🍔 Hunger: {self.hunger} | 😊 Happiness: {self.happiness}")
        print(f"👥 Social: {self.social} | 📱 Paketan: {self.paketan}")
        print("=" * 40)
        print()

    def cek_kondisi(self):
        if self.nilai < 50:
            self.game_over = True
            self.game_over_reason = "NILAI RENDAH! Kamu dikeluarkan dari sekolah."
            return False
        if self.sanity <= 0:
            self.game_over = True
            self.game_over_reason = "BURNOUT TOTAL! Kamu tidak bisa berpikir jernih lagi."
            return False
        if self.hunger <= 0:
            self.game_over = True
            self.game_over_reason = "KELAPARAN! Kamu pingsan karena tidak makan."
            return False
        if all([self.happiness < 10, self.sanity < 10, self.social < 10]):
            self.game_over = True
            self.game_over_reason = "KRISIS MENTAL! Semua aspek hidupmu hancur."
            return False
        return True

    def main_loop(self):
        """Loop utama game"""
        while self.hari <= 30 and not self.game_over:
            self.tampilkan_status()
            if not self.cek_kondisi():
                self.ending_bad()
                return

            # Periksa jatuh tempo utang
            self.periksa_jatuh_tempo_utang()

            # Cek apakah hari libur
            hari_ini = (self.hari - 1) % 7 + 1
            
            if hari_ini in [6, 7]: # Sabtu atau Minggu
                self.hari_libur()
                self.next_day()
                continue

            # Hari sekolah (Senin-Jumat)
            self.hari_sekolah()

            self.next_day()

        if self.hari > 30:
            self.ending_game()

    def hari_sekolah(self):
        """Alur lengkap untuk hari sekolah (Senin-Jumat)"""
        # Pagi: Persiapan berangkat sekolah
        self.pagi_sekolah()
        
        # Siang: Aktivitas di sekolah
        self.aktivitas_sekolah()
        
        # Sore: Pulang sekolah dan kegiatan
        self.sore_setelah_sekolah()

    def hari_libur(self):
        """Alur lengkap untuk hari libur (Sabtu-Minggu)"""
        clear_screen()
        print("=" * 60)
        typing_effect(f"🏖️ HARI LIBUR: {self.jadwal[(self.hari - 1) % 7 + 1]}", 0.05)
        print("=" * 60)
        print()
        
        typing_effect("Hari ini libur! Tidak ada sekolah.", 0.03)
        print()
        
        # Pagi hari libur
        self.tampilkan_status_singkat()
        typing_effect("🌅 PAGI HARI:", 0.03)
        print()
        self.kegiatan_pagi_libur()
        
        # Sore hari libur  
        self.tampilkan_status_singkat()
        typing_effect("🌇 SORE HARI:", 0.03)
        print()
        self.kegiatan_sore_libur()

    def pagi_sekolah(self):
        """Aktivitas pagi sebelum berangkat sekolah"""
        clear_screen()
        print("=" * 60)
        typing_effect(f"🌅 PAGI HARI: BERSIAP KE SEKOLAH", 0.05)
        print("=" * 60)
        print()
        
        typing_effect("Kamu bangun pagi dan bersiap untuk sekolah...", 0.03)
        print()
        
        # Tampilkan status sebelum pilihan sarapan
        self.tampilkan_status_singkat()
        
        # Sarapan pagi
        print("Sarapan pagi:")
        print("1. 🍳 Sarapan di rumah (Gratis! Hunger +15)")
        print("2. 🏪 Beli sarapan (Uang -Rp10.000, Hunger +25)")
        print("3. ❌ Lewati sarapan (Hunger -10)")
        pilihan = input("Pilih (1-3): ")
        print()
        
        if pilihan == "1":
            self.hunger = self.clamp_stat(self.hunger + 15)
            typing_effect("✅ Sarapan sehat di rumah! +15 hunger", 0.03)
        elif pilihan == "2":
            if self.uang >= 10000:
                self.uang -= 10000
                self.hunger = self.clamp_stat(self.hunger + 25)
                typing_effect("✅ Sarapan enak! -Rp10.000, +25 hunger", 0.03)
            else:
                typing_effect("❌ Uang tidak cukup, terpaksa tidak sarapan.", 0.03)
                self.hunger -= 10
        else:
            self.hunger -= 10
            typing_effect("❌ Tidak sarapan, perut keroncongan. -10 hunger", 0.03)
        
        print()
        input("Tekan ENTER untuk berangkat sekolah...")

    def aktivitas_sekolah(self):
        """Aktivitas selama di sekolah"""
        clear_screen()
        print("=" * 60)
        typing_effect("🏫 AKTIVITAS DI SEKOLAH", 0.05)
        print("=" * 60)
        print()
        
        # Event khusus berdasarkan hari
        if self.hari == 1:
            self.event_pertama_hari()
        elif self.hari == 3:
            self.event_bertemu_rina()
        elif self.hari == 5:
            self.event_doni_ajak_jajan()
        elif self.hari == 8:
            self.event_bu_sari_konseling()
        elif self.hari == 12:
            self.event_family_dinner()
        elif self.hari == 15:
            self.event_midpoint_crisis()
        elif self.hari == 20:
            self.mini_game_budget_challenge()
        elif self.hari == 25:
            self.event_final_lesson()
        elif self.hari == 28:
            self.event_final_exam()
        elif self.hari == 30:
            self.event_hari_terakhir()
        else:
            # Event random harian
            self.gacha_event_harian()

        # Makan siang di kantin
        self.makan_siang_kantin()
        
        # Pelajaran dan PR
        self.pelajaran_dan_pr()

    def makan_siang_kantin(self):
        """Makan siang di kantin sekolah"""
        print()
        typing_effect("🍽️ WAKTU MAKAN SIANG:", 0.03)
        print()
        
        # Tampilkan status sebelum pilihan makan siang
        self.tampilkan_status_singkat()
        
        print("Pilihan makan siang:")
        print("1. 🍱 Makan di kantin (Uang -Rp20.000, Hunger +20)")
        print("2. 🍱 Makan bekal (Hunger +10)")
        print("3. 🤢 Puasa (Hunger -20, Sanity -10)")
        pilihan = input("Pilih (1-3): ")
        print()
        
        if pilihan == "1":
            if self.uang >= 20000:
                self.uang -= 20000
                self.hunger = self.clamp_stat(self.hunger + 20)
                typing_effect("✅ Makan siang di kantin! -Rp20.000, +20 hunger", 0.03)
            else:
                typing_effect("❌ Uang tidak cukup, terpaksa puasa.", 0.03)
                self.hunger -= 20
                self.sanity -= 10
        elif pilihan == "2":
            self.hunger = self.clamp_stat(self.hunger + 10)
            typing_effect("✅ Makan bekal yang enak! +10 hunger", 0.03)
        else:
            self.hunger -= 20
            self.sanity -= 10
            typing_effect("❌ Lapar seharian! -20 hunger, -10 sanity", 0.03)

    def pelajaran_dan_pr(self):
        """Pelajaran di sekolah dan PR"""
        print()
        typing_effect("📚 PELAJARAN DI SEKOLAH:", 0.03)
        print()
        
        # Gacha PR
        self.gacha_pr_harian()
        
        # Efek belajar di sekolah
        belajar_bonus = random.randint(1, 3)
        self.nilai += belajar_bonus
        self.sanity -= 5
        typing_effect(f"📖 Mengikuti pelajaran... +{belajar_bonus} nilai, -5 sanity", 0.03)

    def sore_setelah_sekolah(self):
        """Aktivitas sore setelah pulang sekolah"""
        clear_screen()
        print("=" * 60)
        typing_effect("🌇 SORE: PULANG SEKOLAH", 0.05)
        print("=" * 60)
        print()
        
        typing_effect("Kamu sudah pulang sekolah. Waktunya beraktivitas!", 0.03)
        print()
        
        self.tampilkan_status_singkat()
        self.pilihan_kegiatan_sore()

    def kegiatan_pagi_libur(self):
        """Kegiatan pagi di hari libur"""
        print("Kegiatan pagi hari libur:")
        print("1. 🛌 Tidur lebih lama (Sanity +15, Happiness +10)")
        print("2. 🏃‍♂️ Olahraga pagi (Sanity +10, Health +15)")
        print("3. 📖 Belajar mandiri (Nilai +3, Sanity -5)")
        print("4. 🎮 Main game (Happiness +15, Paketan -1)")
        print("5. 🏠 Bantu orang tua (Tabungan +Rp10.000, Sanity +5)")
        pilihan = input("Pilih (1-5): ")
        print()
        
        if pilihan == "1":
            self.sanity = self.clamp_stat(self.sanity + 15)
            self.happiness = self.clamp_stat(self.happiness + 10)
            typing_effect("✅ Tidur berkualitas! +15 sanity, +10 happiness", 0.03)
        elif pilihan == "2":
            self.sanity = self.clamp_stat(self.sanity + 10)
            self.hunger = self.clamp_stat(self.hunger + 15)
            typing_effect("✅ Segar setelah olahraga! +10 sanity, +15 hunger", 0.03)
        elif pilihan == "3":
            self.nilai += 3
            self.sanity -= 5
            typing_effect("✅ Belajar mandiri! +3 nilai, -5 sanity", 0.03)
        elif pilihan == "4":
            self.happiness = self.clamp_stat(self.happiness + 15)
            self.paketan = max(0, self.paketan - 1)
            typing_effect("✅ Main game seru! +15 happiness, -1 paketan", 0.03)
        elif pilihan == "5":
            self.tabungan += 10000
            self.sanity = self.clamp_stat(self.sanity + 5)
            typing_effect("✅ Dapat uang saku! +Rp10.000 tabungan, +5 sanity", 0.03)
        else:
            typing_effect("Pilihan tidak valid. Asumsikan tidur.", 0.03)
            self.sanity = self.clamp_stat(self.sanity + 10)
            self.happiness = self.clamp_stat(self.happiness + 5)

    def kegiatan_sore_libur(self):
        """Kegiatan sore di hari libur"""
        print("Kegiatan sore hari libur:")
        print("1. 👥 Nongkrong dengan teman (Social +20, Uang -Rp20.000)")
        print("2. 🎥 Nonton film (Happiness +20, Paketan -2)")
        print("3. 💰 Review keuangan (Sanity +10, Tabungan +Rp5.000)")
        print("4. 🛒 Jalan-jalan ke mall (Happiness +15, Uang -Rp25.000)")
        print("5. 🧘‍♂️ Istirahat (Sanity +20, Happiness +10)")
        pilihan = input("Pilih (1-5): ")
        print()
        
        if pilihan == "1":
            if self.uang >= 20000:
                self.uang -= 20000
                self.social = self.clamp_stat(self.social + 20)
                typing_effect("✅ Nongkrong seru! -Rp20.000, +20 social", 0.03)
            else:
                typing_effect("❌ Uang tidak cukup untuk nongkrong.", 0.03)
        elif pilihan == "2":
            if self.paketan >= 2:
                self.paketan -= 2
                self.happiness = self.clamp_stat(self.happiness + 20)
                typing_effect("✅ Nonton film seru! -2 paketan, +20 happiness", 0.03)
            else:
                typing_effect("❌ Kuota tidak cukup untuk streaming.", 0.03)
        elif pilihan == "3":
            self.sanity = self.clamp_stat(self.sanity + 10)
            self.tabungan += 5000
            typing_effect("✅ Finansial terkontrol! +10 sanity, +Rp5.000 tabungan", 0.03)
        elif pilihan == "4":
            if self.uang >= 25000:
                self.uang -= 25000
                self.happiness = self.clamp_stat(self.happiness + 15)
                typing_effect("✅ Jalan-jalan menyenangkan! -Rp25.000, +15 happiness", 0.03)
            else:
                typing_effect("❌ Uang tidak cukup untuk jalan-jalan.", 0.03)
        elif pilihan == "5":
            self.sanity = self.clamp_stat(self.sanity + 20)
            self.happiness = self.clamp_stat(self.happiness + 10)
            typing_effect("✅ Istirahat total! +20 sanity, +10 happiness", 0.03)
        else:
            typing_effect("Pilihan tidak valid. Asumsikan istirahat.", 0.03)
            self.sanity = self.clamp_stat(self.sanity + 15)
            self.happiness = self.clamp_stat(self.happiness + 5)

    def pilihan_kegiatan_sore(self):
        """Pilihan kegiatan sore setelah pulang sekolah"""
        print("Pilihan Kegiatan Sore:")
        print("1. 📚 Belajar (Nilai +random(2-5), Sanity -10)")
        print("2. 📱 Online (Paketan -2, Happiness +10)")
        print("3. 🏃‍♂️ Olahraga (Sanity +10, Happiness +5)")
        print("4. 👥 Nongkrong (Social +25, Happiness +15, Uang -Rp25.000)")
        print("5. 💰 Nabung (Uang -> Tabungan)")
        print("6. 🛒 Jajan (Uang -Rp10.000, Happiness +20)")
        print("7. 😴 Tidur (Sanity +20, Happiness +5)")
        pilihan = input("Pilih kegiatan (1-7): ")
        print()
        if pilihan == "1":
            self.aksi_belajar()
        elif pilihan == "2":
            self.aksi_online()
        elif pilihan == "3":
            self.aksi_olahraga()
        elif pilihan == "4":
            self.aksi_nongkrong()
        elif pilihan == "5":
            self.aksi_nabung()
        elif pilihan == "6":
            self.aksi_jajan()
        elif pilihan == "7":
            self.aksi_istirahat()
        else:
            typing_effect("Pilihan tidak valid. Asumsikan tidur.", 0.03)
            self.aksi_istirahat()

    def gacha_event_harian(self):
        """Gacha event harian termasuk PR"""
        events = [
            self.event_kantin_murah,
            self.event_teman_pinjam_uang,
            self.event_promo_kuota,
            self.event_hujan_transport,
            self.event_free_wifi,
            self.event_uang_hilang
        ]
        # Pilih satu event secara acak
        event = random.choice(events)
        event()

    def gacha_pr_harian(self):
        """Gacha PR harian"""
        # Pilih pelajaran secara acak
        pelajaran = random.choice([
            "Matematika", "Bahasa Indonesia", "Fisika", "Kimia", "Biologia",
            "Ekonomi", "Sejarah", "Geografi", "Sosiologi", "Psikologi"
        ])
        # Tentukan apakah ada PR
        ada_pr = random.randint(1, 100) <= 60 # 60% chance ada PR

        if ada_pr:
            self.pr_pelajaran = pelajaran
            self.pr_beres = False
            print("=" * 60)
            typing_effect(f"📝 PR {self.pr_pelajaran}", 0.05)
            print("=" * 60)
            print()
            # Dialog guru
            guru_map = {
                "Matematika": "Pak Budi",
                "Bahasa Indonesia": "Bu Sari",
                "Fisika": "Pak Joko",
                "Kimia": "Bu Lina",
                "Biologia": "Pak Sigit",
                "Ekonomi": "Bu Rini",
                "Sejarah": "Pak Agus",
                "Geografi": "Bu Maya",
                "Sosiologi": "Pak Dedi",
                "Psikologi": "Bu Tari"
            }
            guru = guru_map.get(pelajaran, "Guru")
            typing_effect(f"[{self.nama_pemain} di kelas, guru membagikan PR]", 0.03)
            print()
            time.sleep(1)
            dialog(guru, f"Anak-anak, PR {self.pr_pelajaran} ini harus dikumpulkan besok!", emosi="firm")
            dialog(guru, "Ini PR yang penting, jangan lupa dikerjakan semua!", emosi="strict")
            dialog(guru, "PERINGATAN: Nilai kalian harus di atas KKM (82)!", emosi="strict")
            print()
            
            # Tampilkan status sebelum pilihan PR
            self.tampilkan_status_singkat()
            
            print("Pilihanmu:")
            print("1. 📚 Kerjakan PR (Sanity -15, Nilai +random(4-8), Hunger -20)")
            print("2. 😴 Tidur, cuekin PR (Nilai -random(5-10), Happiness +15)")
            pilihan = input("Pilih (1-2): ")
            print()
            if pilihan == "1":
                self.sanity -= 15
                self.nilai += random.randint(4, 8)
                self.hunger -= 20
                self.pr_beres = True
                typing_effect(f"✅ Kamu mengerjakan PR {self.pr_pelajaran}!", 0.03)
                typing_effect("🧠 -15 sanity (capek mikir)", 0.03)
                typing_effect("📚 +nilai (skill meningkat)", 0.03)
                typing_effect("🍔 -20 hunger (lupa makan)", 0.03)
            elif pilihan == "2":
                self.nilai -= random.randint(5, 10)
                self.happiness += 15
                typing_effect(f"❌ Kamu tidak mengerjakan PR {self.pr_pelajaran}.", 0.03)
                typing_effect("📚 -nilai (guru kecewa)", 0.03)
                typing_effect("😊 +15 happiness (tidur nyenyak)", 0.03)
            else:
                typing_effect("Pilihan tidak valid. Asumsikan kamu tidak mengerjakan.", 0.03)
                self.nilai -= random.randint(5, 10)

    def periksa_jatuh_tempo_utang(self):
        """Periksa apakah ada utang yang jatuh tempo hari ini"""
        utang_baru_masuk = []
        for pemberi, jumlah, jatuh_tempo in self.utang_masuk:
            if self.hari >= jatuh_tempo:
                self.uang += jumlah
                typing_effect(f"✅ {pemberi} mengembalikan uang pinjaman Rp{jumlah:,}!", 0.03)
                print()
            else:
                utang_baru_masuk.append((pemberi, jumlah, jatuh_tempo))
        self.utang_masuk = utang_baru_masuk

        utang_baru_keluar = []
        for penerima, jumlah, jatuh_tempo in self.utang_keluar:
            if self.hari >= jatuh_tempo:
                if self.uang >= jumlah:
                    self.uang -= jumlah
                    typing_effect(f"❌ Kamu membayar utang Rp{jumlah:,} ke {penerima}.", 0.03)
                    print()
                else:
                    self.utang += jumlah
                    typing_effect(f"❌ Uang tidak cukup, utang bertambah Rp{jumlah:,} ke {penerima}.", 0.03)
                    print()
            else:
                utang_baru_keluar.append((penerima, jumlah, jatuh_tempo))
        self.utang_keluar = utang_baru_keluar

    def event_kantin_murah(self):
        print("=" * 60)
        typing_effect("🍜 PROMO KANTIN MURAH", 0.05)
        print("=" * 60)
        print()
        typing_effect("Kantin sekolah sedang ada promo spesial!", 0.03)
        typing_effect("Makan siang lengkap + es teh hanya Rp12.000!", 0.03)
        print()
        pilihan = input("Mau beli? (y/n): ").lower()
        print()
        if pilihan == 'y' and self.uang >= 12000:
            self.uang -= 12000
            self.hunger = self.clamp_stat(self.hunger + 30)
            self.happiness = self.clamp_stat(self.happiness + 10)
            typing_effect("✅ Hemat! +30 hunger, +10 happiness", 0.03)
        elif pilihan == 'y':
            typing_effect("❌ Uang tidak cukup...", 0.03)
        else:
            self.hunger -= 5
            typing_effect("❌ Lapar karena tidak memanfaatkan promo", 0.03)

    def event_teman_pinjam_uang(self):
        print("=" * 60)
        typing_effect("🤝 TEMAN PINJAM UANG", 0.05)
        print("=" * 60)
        print()
        teman = random.choice(["Budi", "Andi", "Sari", "Dina"])
        jumlah = random.randint(10000, 30000)
        typing_effect(f"[{teman} menghampirimu dengan wajah cemas]", 0.03)
        print()
        time.sleep(1)
        dialog(teman, f"Bro... bisa pinjam Rp{jumlah:,} nggak?", emosi="worried")
        print()
        print("Pilihanmu:")
        print(f"1. ✅ Bantu (Uang -Rp{jumlah:,}, Hubungan +15)")
        print("2. ❌ Tidak bisa bantu (Hubungan -10)")
        pilihan = input("Pilih (1-2): ")
        print()
        if pilihan == "1" and self.uang >= jumlah:
            self.uang -= jumlah
            self.utang_masuk.append((teman, jumlah, self.hari + 7)) # Harus dikembalikan dalam 7 hari
            typing_effect(f"✅ Kamu meminjamkan Rp{jumlah:,} ke {teman}.", 0.03)
            typing_effect("✅ Hubungan meningkat.", 0.03)
        elif pilihan == "1":
            typing_effect("❌ Uang tidak cukup untuk membantu.", 0.03)
            typing_effect("❌ Hubungan menurun.", 0.03)
        elif pilihan == "2":
            typing_effect(f"❌ Kamu tidak bisa membantu {teman}.", 0.03)
            typing_effect("❌ Hubungan menurun.", 0.03)
        else:
            typing_effect("Pilihan tidak valid.", 0.03)

    def event_promo_kuota(self):
        print("=" * 60)
        typing_effect("📶 PROMO PAKET DATA", 0.05)
        print("=" * 60)
        print()
        typing_effect("Ada promo besar-besaran! 15GB hanya Rp25.000!", 0.03)
        print()
        pilihan = input("Mau beli? (y/n): ").lower()
        print()
        if pilihan == 'y' and self.uang >= 25000:
            self.uang -= 25000
            self.paketan += 15
            typing_effect("✅ Kuota kamu bertambah! Siap streaming!", 0.03)
        elif pilihan == 'y':
            typing_effect("❌ Uang tidak cukup untuk beli paket data.", 0.03)
        else:
            typing_effect("Kamu memilih untuk hemat kuota.", 0.03)

    def event_hujan_transport(self):
        print("=" * 60)
        typing_effect("🌧️ HUJAN DERAS", 0.05)
        print("=" * 60)
        print()
        typing_effect("Pulang sekolah hujan deras. Teman menawarkan ojek online.", 0.03)
        print()
        biaya = random.randint(15000, 25000)
        print(f"Pilihanmu:")
        print(f"1. 🚖 Ambil ojek (Uang -Rp{biaya:,}, Sanity +10)")
        print(f"2. 🚶 Jalan kaki (Hunger -10, Sanity -15)")
        pilihan = input("Pilih (1-2): ")
        print()
        if pilihan == "1" and self.uang >= biaya:
            self.uang -= biaya
            self.sanity = self.clamp_stat(self.sanity + 10)
            typing_effect(f"✅ Sampai rumah dengan aman dan nyaman. -Rp{biaya:,}", 0.03)
        elif pilihan == "1":
            typing_effect("❌ Uang tidak cukup, terpaksa jalan kaki.", 0.03)
            self.hunger = self.clamp_stat(self.hunger - 10)
            self.sanity = self.clamp_stat(self.sanity - 15)
            typing_effect("❌ Kelaparan dan kedinginan. -10 hunger, -15 sanity", 0.03)
        elif pilihan == "2":
            self.hunger = self.clamp_stat(self.hunger - 10)
            self.sanity = self.clamp_stat(self.sanity - 15)
            typing_effect("❌ Jalan kaki di hujan. Capek dan basah. -10 hunger, -15 sanity", 0.03)
        else:
            typing_effect("Pilihan tidak valid. Asumsikan jalan kaki.", 0.03)
            self.hunger = self.clamp_stat(self.hunger - 10)
            self.sanity = self.clamp_stat(self.sanity - 15)

    def event_free_wifi(self):
        print("=" * 60)
        typing_effect("📶 WIFI GRATIS", 0.05)
        print("=" * 60)
        print()
        typing_effect("Kamu menemukan tempat dengan wifi gratis dan kencang!", 0.03)
        print()
        typing_effect("Kamu bisa hemat kuota dan menyelesaikan tugas online.", 0.03)
        self.paketan = self.clamp_stat(self.paketan + 5)
        self.sanity = self.clamp_stat(self.sanity + 10)
        typing_effect("✅ Kuota terselamatkan! +5 paketan, +10 sanity", 0.03)

    def event_uang_hilang(self):
        print("=" * 60)
        typing_effect("💸 UANG HILANG!", 0.05)
        print("=" * 60)
        print()
        typing_effect("Kamu kehilangan sebagian uang jajan karena dompetmu jatuh.", 0.03)
        print()
        jumlah_hilang = random.randint(10000, 30000)
        self.uang -= jumlah_hilang
        self.sanity -= 15
        typing_effect(f"❌ Uangmu berkurang Rp{jumlah_hilang:,}! -15 sanity", 0.03)
        if self.uang < 0:
            self.uang = 0

    def event_pertama_hari(self):
        """Event hari pertama - perkenalan dengan dunia game"""
        print("=" * 60)
        typing_effect("📖 HARI PERTAMA DI SEKOLAH", 0.05)
        print("=" * 60)
        print()
        typing_effect("[Di halaman sekolah]", 0.04)
        print()
        time.sleep(1)
        typing_effect("Kamu baru pertama kali merasakan hidup mandiri dengan uang jajan terbatas.", 0.03)
        typing_effect("Gedung sekolah megah berdiri di depanmu, penuh dengan godaan konsumtif.", 0.03)
        print()
        time.sleep(1)
        typing_effect("Kamu menghela nafas dalam-dalam, lalu melangkah masuk.", 0.04)
        print()
        time.sleep(1)
        dialog(self.nama_pemain, "(Dalam hati) Oke, ini baru awal. Aku bisa atur semuanya.", emosi="determined")
        print()
        time.sleep(1)
        typing_effect("Kamu menerima uang jajan bulanan dari orang tua.", 0.03)
        self.uang += 100000
        typing_effect("✅ +Rp100.000 uang jajan!", 0.03)
        typing_effect("Kamu harus bijak menggunakannya selama sebulan.", 0.03)
        print()
        time.sleep(2)

    def event_bertemu_rina(self):
        """Event bertemu Rina - karakter yang bijak finansial"""
        print("=" * 60)
        typing_effect("👩‍💼 BERTEMU RINA - TEMAN YANG BIJAK", 0.05)
        print("=" * 60)
        print()
        typing_effect("[Di perpustakaan sekolah]", 0.04)
        print()
        time.sleep(1)
        dialog("Rina", f"Hai {self.nama_pemain}! Lagi baca buku apa?", emosi="friendly")
        print()
        time.sleep(1)
        dialog(self.nama_pemain, "Eh, Rina! Lagi baca buku tentang investasi nih...", emosi="curious")
        print()
        time.sleep(1)
        dialog("Rina", "Wah, bagus! Aku juga suka belajar tentang keuangan.", emosi="excited")
        dialog("Rina", "Tips dariku: selalu alokasikan 20% uang jajan untuk tabungan!", emosi="wise")
        print()
        time.sleep(1)
        self.story_flags['bertemu_rina'] = True
        self.add_achievement("Pertemanan Bijak")

    def event_doni_ajak_jajan(self):
        """Event Doni mengajak jajan"""
        print("=" * 60)
        typing_effect("👨‍💼 DONI AJAK JAJAN", 0.05)
        print("=" * 60)
        print()
        typing_effect("[Di depan kantin]", 0.04)
        print()
        time.sleep(1)
        dialog("Doni", f"Bro {self.nama_pemain}! Ayo jajan, ada promo nih!", emosi="excited")
        print()
        time.sleep(1)
        print("Pilihanmu:")
        print("1. ✅ Ikut jajan (Uang -Rp20.000, Social +15, Happiness +10)")
        print("2. ❌ Menolak dengan halus (Social -5, Sanity +5)")
        print("3. 💡 Ajak nabung (Social +10, Tabungan +Rp10.000)")
        pilihan = input("Pilih (1-3): ")
        print()
        
        if pilihan == "1":
            if self.uang >= 20000:
                self.uang -= 20000
                self.social = self.clamp_stat(self.social + 15)
                self.happiness = self.clamp_stat(self.happiness + 10)
                typing_effect("✅ Jajan seru dengan Doni! -Rp20.000, +15 social, +10 happiness", 0.03)
            else:
                typing_effect("❌ Uang tidak cukup, terpaksa menolak.", 0.03)
                self.social -= 5
        elif pilihan == "2":
            self.social -= 5
            self.sanity = self.clamp_stat(self.sanity + 5)
            typing_effect("❌ Doni sedikit kecewa. -5 social, +5 sanity", 0.03)
        elif pilihan == "3":
            if self.uang >= 10000:
                self.uang -= 10000
                self.tabungan += 10000
                self.social = self.clamp_stat(self.social + 10)
                typing_effect("✅ Doni terinspirasi! +10 social, +Rp10.000 tabungan", 0.03)
                self.add_achievement("Influencer Keuangan")
            else:
                typing_effect("❌ Uang tidak cukup untuk menabung.", 0.03)
        else:
            typing_effect("Pilihan tidak valid.", 0.03)

    def event_bu_sari_konseling(self):
        """Event konseling dengan Bu Sari"""
        print("=" * 60)
        typing_effect("👩‍🏫 KONSELING DENGAN BU SARI", 0.05)
        print("=" * 60)
        print()
        typing_effect("[Di ruang konseling]", 0.04)
        print()
        time.sleep(1)
        dialog("Bu Sari", f"{self.nama_pemain}, bagaimana keadaanmu akhir-akhir ini?", emosi="caring")
        print()
        time.sleep(1)
        
        print("Jawabanmu:")
        print("1. 💰 Kesulitan mengatur uang")
        print("2. 📚 Terlalu banyak tekanan akademik") 
        print("3. 😊 Semua baik-baik saja")
        pilihan = input("Pilih (1-3): ")
        print()
        
        if pilihan == "1":
            dialog(self.nama_pemain, "Saya kesulitan mengatur uang jajan, Bu...", emosi="worried")
            print()
            dialog("Bu Sari", "Itu wajar. Coba buat anggaran sederhana dan prioritaskan kebutuhan.", emosi="wise")
            self.sanity += 15
            self.add_achievement("Sadar Finansial")
        elif pilihan == "2":
            dialog(self.nama_pemain, "Saya merasa terbebani dengan pelajaran...", emosi="tired")
            print()
            dialog("Bu Sari", "Istirahat yang cukup dan jangan lupa me-time. Kesehatan mental penting!", emosi="caring")
            self.sanity += 20
        else:
            dialog(self.nama_pemain, "Semua baik-baik saja, Bu!", emosi="happy")
            print()
            dialog("Bu Sari", "Bagus! Tapi ingat, selalu jaga keseimbangan hidup.", emosi="smile")
            self.happiness += 10
        
        typing_effect("✅ Konseling memberikan pencerahan!", 0.03)

    def event_family_dinner(self):
        """Event makan malam keluarga"""
        print("=" * 60)
        typing_effect("🍽️ MAKAN MALAM KELUARGA", 0.05)
        print("=" * 60)
        print()
        typing_effect("[Di rumah, meja makan]", 0.04)
        print()
        time.sleep(1)
        dialog("Ibu", f"{self.nama_pemain}, bagaimana kabarmu di sekolah?", emosi="caring")
        print()
        time.sleep(1)
        
        print("Jawabanmu:")
        print("1. 😊 Cerita hal positif")
        print("2. 😔 Keluhkan kesulitan")
        print("3. 🤐 Diam saja")
        pilihan = input("Pilih (1-3): ")
        print()
        
        if pilihan == "1":
            dialog(self.nama_pemain, "Saya baik, Bu! Baru belajar tentang menabung...", emosi="happy")
            print()
            dialog("Ayah", "Wah, anakku sudah besar! Ini hadiah untukmu.", emosi="proud")
            self.tabungan += 50000
            self.happiness += 15
            typing_effect("✅ Dapat bonus Rp50.000 dari Ayah!", 0.03)
        elif pilihan == "2":
            dialog(self.nama_pemain, "Agak sulit mengatur uang jajan...", emosi="sad")
            print()
            dialog("Ibu", "Tenang, Nak. Ibu akan beri tips mengatur keuangan.", emosi="supportive")
            self.sanity += 10
            self.add_achievement("Terbuka dengan Keluarga")
        else:
            dialog(self.nama_pemain, "...", emosi="quiet")
            print()
            dialog("Ibu", "Ada apa, Nak? Jangan dipendam sendiri.", emosi="worried")
            self.sanity -= 5
        
        self.story_flags['family_dinner'] = True

    def event_midpoint_crisis(self):
        """Event krisis di pertengahan bulan"""
        print("=" * 60)
        typing_effect("⚡ KRISIS TENGAH BULAN", 0.05)
        print("=" * 60)
        print()
        typing_effect("Uang jajan mulai menipis...", 0.04)
        typing_effect("Tekanan akademik meningkat...", 0.04)
        typing_effect("Kamu merasa lelah...", 0.04)
        print()
        time.sleep(2)
        
        print("Bagaimana kamu menghadapinya?")
        print("1. 💪 Tetap semangat dan berusaha")
        print("2. 😴 Menyerah dan putus asa")
        print("3. 🆘 Minta bantuan orang tua")
        pilihan = input("Pilih (1-3): ")
        print()
        
        if pilihan == "1":
            typing_effect("Kamu memutuskan untuk tetap kuat!", 0.03)
            self.sanity += 10
            self.happiness += 5
            self.add_achievement("Pemberani")
        elif pilihan == "2":
            typing_effect("Kamu merasa terjebak dalam keputusasaan...", 0.03)
            self.sanity -= 15
            self.happiness -= 10
        else:
            typing_effect("Orang tua memberimu dukungan moral dan finansial.", 0.03)
            self.uang += 30000
            self.sanity += 5
            typing_effect("✅ +Rp30.000 bantuan darurat", 0.03)
        
        self.story_flags['krisis_pertama'] = True

    def mini_game_budget_challenge(self):
        """Mini game tantangan anggaran"""
        print("=" * 60)
        typing_effect("💰 TANTANGAN ANGGARAN", 0.05)
        print("=" * 60)
        print()
        typing_effect("Bu Sari memberikan tantangan mengatur anggaran!", 0.03)
        print()
        
        budget = 100000
        typing_effect(f"Kamu punya Rp{budget:,} untuk dialokasikan ke:", 0.03)
        print()
        
        # Pemain harus mengalokasikan anggaran
        print("1. 🍔 Makanan (minimal 40%)")
        print("2. 📚 Pendidikan (minimal 30%)") 
        print("3. 😊 Hiburan (maksimal 20%)")
        print("4. 💰 Tabungan (sisanya)")
        print()
        
        try:
            makanan = int(input("Berapa % untuk makanan? "))
            pendidikan = int(input("Berapa % untuk pendidikan? "))
            hiburan = int(input("Berapa % untuk hiburan? "))
            
            total = makanan + pendidikan + hiburan
            
            if total > 100:
                typing_effect("❌ Total melebihi 100%! Tantangan gagal.", 0.03)
                self.sanity -= 5
                return
                
            if makanan < 40:
                typing_effect("❌ Alokasi makanan kurang dari 40%!", 0.03)
                self.hunger -= 10
            if pendidikan < 30:
                typing_effect("❌ Alokasi pendidikan kurang dari 30%!", 0.03)
                self.nilai -= 5
            if hiburan > 20:
                typing_effect("❌ Alokasi hiburan melebihi 20%!", 0.03)
                self.sanity -= 5
                
            tabungan = 100 - total
            tabungan_rp = int(budget * tabungan / 100)
            
            if makanan >= 40 and pendidikan >= 30 and hiburan <= 20:
                typing_effect("✅ Selamat! Anggaranmu ideal!", 0.03)
                self.tabungan += tabungan_rp
                self.sanity += 10
                self.add_achievement("Ahli Anggaran")
                self.story_flags['budget_challenge_success'] = True
            else:
                typing_effect("⚠️ Anggaran perlu perbaikan, tapi kamu belajar sesuatu!", 0.03)
                self.sanity += 5
                
        except:
            typing_effect("❌ Input tidak valid!", 0.03)

    def event_final_lesson(self):
        """Event pelajaran akhir tentang kebebasan finansial"""
        print("=" * 60)
        typing_effect("🎓 PELAJARAN AKHIR: KEBEBASAN FINANSIAL", 0.05)
        print("=" * 60)
        print()
        typing_effect("[Di kelas ekonomi]", 0.04)
        print()
        time.sleep(1)
        dialog("Bu Sari", "Anak-anak, kebebasan finansial bukan tentang menjadi kaya...", emosi="wise")
        dialog("Bu Sari", "...tapi tentang memiliki kendali atas keuangan dan hidupmu.", emosi="passionate")
        print()
        time.sleep(1)
        dialog("Bu Sari", f"{self.nama_pemain}, apa yang sudah kamu pelajari?", emosi="curious")
        print()
        
        print("Jawabanmu:")
        print("1. 💡 Pentingnya menabung")
        print("2. ⚖️ Keseimbangan hidup")
        print("3. 🎯 Prioritas kebutuhan")
        pilihan = input("Pilih (1-3): ")
        print()
        
        if pilihan == "1":
            dialog(self.nama_pemain, "Saya belajar menabung untuk masa depan.", emosi="proud")
            self.tabungan += 20000
        elif pilihan == "2":
            dialog(self.nama_pemain, "Hidup perlu keseimbangan antara kerja dan istirahat.", emosi="wise")
            self.sanity += 10
            self.happiness += 10
        else:
            dialog(self.nama_pemain, "Saya belajar memprioritaskan kebutuhan daripada keinginan.", emosi="confident")
            self.uang += 15000
            
        typing_effect("✅ Kamu mendapatkan insight berharga!", 0.03)
        self.add_achievement("Pelajaran Hidup")

    def event_final_exam(self):
        """Event ujian akhir"""
        print("=" * 60)
        typing_effect("📝 UJIAN AKHIR", 0.05)
        print("=" * 60)
        print()
        typing_effect("Hari ujian akhir telah tiba!", 0.04)
        print()
        
        # Nilai ujian tergantung pada persiapan
        base_score = self.nilai
        preparation_bonus = random.randint(0, 20)
        final_score = min(100, base_score + preparation_bonus)
        
        typing_effect(f"Nilai akhir kamu: {final_score}", 0.04)
        print()
        
        if final_score >= 80:
            typing_effect("🎉 LUAR BIASA! Kamu lulus dengan nilai memuaskan!", 0.03)
            self.happiness += 20
            self.tabungan += 50000
            typing_effect("✅ Dapat bonus Rp50.000 dari orang tua!", 0.03)
            self.add_achievement("Juara Kelas")
        elif final_score >= 60:
            typing_effect("✅ Selamat! Kamu lulus ujian.", 0.03)
            self.happiness += 10
        else:
            typing_effect("😔 Nilaimu kurang memuaskan, tapi kamu masih bisa memperbaiki.", 0.03)
            self.sanity -= 10
            
        self.story_flags['final_exam'] = True

    def event_hari_terakhir(self):
        """Event hari terakhir sekolah"""
        print("=" * 60)
        typing_effect("🎉 HARI TERAKHIR", 0.05)
        print("=" * 60)
        print()
        typing_effect("Ini adalah hari terakhirmu di sekolah...", 0.04)
        print()
        time.sleep(1)
        
        # Evaluasi akhir berdasarkan pilihan selama game
        total_tabungan = self.tabungan
        total_utang = self.utang
        
        typing_effect("Refleksi perjalananmu:", 0.04)
        print()
        
        if total_tabungan > 200000:
            typing_effect("💎 Kamu berhasil menabung dengan konsisten!", 0.03)
        if total_utang == 0:
            typing_effect("✅ Kamu bebas dari utang! Keputusan yang bijak.", 0.03)
        if self.nilai >= 80:
            typing_effect("📚 Prestasi akademismu membanggakan!", 0.03)
        if self.sanity >= 70:
            typing_effect("🧠 Kamu berhasil menjaga kesehatan mental!", 0.03)
            
        print()
        typing_effect("Perjalanan ini telah mengajarkanmu banyak hal...", 0.04)
        time.sleep(2)

    def aksi_belajar(self):
        loading_animation("Belajar", 2)
        print()
        nilai_tambahan = random.randint(2, 5)
        self.nilai += nilai_tambahan
        self.sanity = self.clamp_stat(self.sanity - 10)
        typing_effect(f"📚 Belajar keras! +{nilai_tambahan} nilai, -10 sanity", 0.03)
        # Tampilkan status setelah kegiatan
        self.tampilkan_status_singkat()
        if self.nilai >= 50:
            self.add_achievement("Pelajar Teladan")

    def aksi_online(self):
        loading_animation("Online", 2)
        print()
        self.paketan -= 2
        self.happiness = self.clamp_stat(self.happiness + 10)
        typing_effect("📱 Scroll media sosial. +10 happiness, -2 paketan", 0.03)
        # Tampilkan status setelah kegiatan
        self.tampilkan_status_singkat()

    def aksi_olahraga(self):
        loading_animation("Olahraga", 2)
        print()
        self.sanity = self.clamp_stat(self.sanity + 10)
        self.happiness = self.clamp_stat(self.happiness + 5)
        typing_effect("🏃‍♂️ Olahraga ringan. +10 sanity, +5 happiness", 0.03)
        # Tampilkan status setelah kegiatan
        self.tampilkan_status_singkat()

    def aksi_nongkrong(self):
        loading_animation("Menyiapkan nongkrong", 2)
        print()
        if self.uang >= 25000:
            self.uang -= 25000
            self.social = self.clamp_stat(self.social + 25)
            self.happiness = self.clamp_stat(self.happiness + 15)
            self.hunger -= 10
            typing_effect("👥 Nongkrong seru! Teman-teman senang!", 0.03)
            if random.randint(1, 100) <= 30:
                typing_effect("💡 Plot twist: Teman traktir kamu balik!", 0.03)
                self.uang += 15000
                typing_effect("✅ Dapat bonus Rp15.000!", 0.03)
        else:
            typing_effect("❌ Uang tidak cukup untuk nongkrong!", 0.03)
        # Tampilkan status setelah kegiatan
        self.tampilkan_status_singkat()

    def aksi_jajan(self):
        loading_animation("Jajan", 2)
        print()
        if self.uang >= 10000:
            self.uang -= 10000
            self.happiness = self.clamp_stat(self.happiness + 20)
            typing_effect("🛒 Jajan enak! +20 happiness", 0.03)
        else:
            typing_effect("❌ Uang tidak cukup untuk jajan!", 0.03)
        # Tampilkan status setelah kegiatan
        self.tampilkan_status_singkat()

    def aksi_istirahat(self):
        loading_animation("Beristirahat", 2)
        print()
        self.sanity = self.clamp_stat(self.sanity + 20)
        self.happiness = self.clamp_stat(self.happiness + 5)
        typing_effect("😴 Tidur nyenyak. +20 sanity, +5 happiness", 0.03)
        # Tampilkan status setelah kegiatan
        self.tampilkan_status_singkat()

    def aksi_nabung(self):
        loading_animation("Menabung", 2)
        print()
        if self.uang > 0:
            try:
                jumlah = int(input(f"Masukkan jumlah uang yang ingin ditabung (Uang: Rp{self.uang:,}): "))
                if jumlah > 0 and jumlah <= self.uang:
                    self.uang -= jumlah
                    self.tabungan += jumlah
                    typing_effect(f"✅ Berhasil menabung Rp{jumlah:,}!", 0.03)
                    typing_effect("💎 +tabungan, -uang, +10 sanity (bangga!)", 0.03)
                    self.sanity = self.clamp_stat(self.sanity + 10)
                    if self.tabungan >= 50000 and not self.story_flags['save_master']:
                        self.add_achievement("Master Menabung")
                        self.story_flags['save_master'] = True
                else:
                    typing_effect("❌ Jumlah tidak valid!", 0.03)
            except:
                typing_effect("❌ Input tidak valid!", 0.03)
        else:
            typing_effect("❌ Uang tidak cukup untuk nabung!", 0.03)
        # Tampilkan status setelah kegiatan
        self.tampilkan_status_singkat()

    def next_day(self):
        """Lanjut ke hari berikutnya"""
        print()
        time.sleep(1)
        
        # Clear screen sebelum menampilkan hari berikutnya
        clear_screen()
        
        # Apply overflow effects sebelum hari berakhir
        self.apply_overflow_effects()
        
        # Tampilkan status sebelum menunggu input
        print("=" * 60)
        typing_effect(f"📅 HARI BERIKUTNYA: HARI {self.hari + 1}", 0.04)
        print("=" * 60)
        print(f"💰 Uang Jajan: Rp{self.uang:,}")
        print(f"💎 Tabungan: Rp{self.tabungan:,}")
        print(f"💳 Utang: Rp{self.utang:,}")
        print(f"📊 Nilai: {self.nilai}")
        print(f"🧠 Sanity: {self.sanity}")
        print(f"🍔 Hunger: {self.hunger}")
        print(f"😊 Happiness: {self.happiness}")
        print(f"👥 Social: {self.social}")
        print(f"📱 Paketan: {self.paketan}")
        print("-" * 60)
        
        # Tunggu input sebelum ke hari berikutnya
        input("⏭️ Tekan ENTER untuk melanjutkan ke hari berikutnya...")
        clear_screen()
        
        self.hari += 1
        self.hunger -= random.randint(8, 15)
        self.paketan -= random.randint(1, 3)
        self.paketan = max(0, self.paketan)
        # Reset status PR
        self.pr_pelajaran = ""
        self.pr_beres = False
        # Efek utang
        if self.utang > 0:
            bunga = int(self.utang * 0.05)
            self.utang += bunga
            self.sanity -= 5
            self.happiness -= 3
        # Efek paketan habis
        if self.paketan == 0:
            self.happiness -= 5
            self.social -= 5
        # Tabungan bertumbuh
        if self.tabungan > 0:
            bunga_tabungan = int(self.tabungan * 0.01)
            self.tabungan += bunga_tabungan

    def ending_game(self):
        """Sistem multiple endings berdasarkan pilihan pemain"""
        clear_screen()
        print("=" * 60)
        typing_effect("🎉 30 HARI TELAH BERLALU!", 0.05)
        print("=" * 60)
        print()
        # Hitung skor akhir berdasarkan berbagai faktor
        financial_score = (self.tabungan * 0.5) - (self.utang * 0.3)
        academic_score = self.nilai * 2
        mental_score = (self.sanity + self.happiness + self.social) / 3
        total_score = financial_score + academic_score + mental_score

        print("Status akhir kamu:")
        print(f"- Uang: Rp{self.uang:,}")
        print(f"- Tabungan: Rp{self.tabungan:,}")
        print(f"- Utang: Rp{self.utang:,}")
        print(f"- Nilai: {self.nilai}")
        print(f"- Sanity: {self.sanity}")
        print(f"- Happiness: {self.happiness}")
        print(f"- Social: {self.social}")
        print(f"- Total Score: {total_score:.2f}")
        print()
        time.sleep(2)

        # Ending berdasarkan kondisi
        if self.tabungan >= 500000 and self.utang == 0:
            typing_effect("🏆🏆🏆 FINANCIAL FREEDOM ACHIEVED! 🏆🏆🏆", 0.04)
            typing_effect("Kamu adalah seorang master keuangan!", 0.03)
            typing_effect("Kamu berhasil mengatur keuangan, nilai, dan kesehatan mentalmu dengan sempurna.", 0.03)
            typing_effect("✨ Kamu menjadi role model untuk adik kelas tentang financial wisdom.", 0.03)
        elif self.tabungan >= 200000 and self.utang == 0:
            typing_effect("🎉 LUAR BIASA! Kamu lulus dengan nilai memuaskan dan bebas utang!", 0.03)
            typing_effect("Kamu masih memiliki beberapa utang kecil, tapi sudah punya rencana melunasinya.", 0.03)
            typing_effect("Hubungan dengan teman-teman tetap terjaga, dan prestasi akademik membaik.", 0.03)
        elif self.utang == 0 and self.nilai >= 70:
            typing_effect("✅ Selamat! Kamu berhasil melewati bulan ini dengan baik.", 0.03)
            typing_effect("Kamu belajar banyak hal dan berhasil menjaga keuangan tetap sehat.", 0.03)
        else:
            typing_effect("💡 Kamu telah belajar banyak hal penting hari ini.", 0.03)
            typing_effect("Meski tidak meraih semua tujuan, kamu mendapatkan sesuatu yang lebih berharga:", 0.03)
            print()
            time.sleep(1)
            typing_effect("- Ketahanan mental", 0.03)
            typing_effect("- Pelajaran hidup yang mendalam", 0.03)
            typing_effect("- Motivasi untuk terus berkembang", 0.03)

        print()
        typing_effect("Terima kasih telah menjalani perjalanan ini.", 0.03)
        typing_effect("Kamu pantas bangga karena tidak menyerah.", 0.03)
        print("=" * 60)
        typing_effect("YOUR JOURNEY CONTINUES...", 0.05)
        print("=" * 60)

    def ending_bad(self):
        clear_screen()
        print("=" * 60)
        typing_effect("💀 GAME OVER", 0.05)
        print("=" * 60)
        print()
        typing_effect(f"Alasan: {self.game_over_reason}", 0.04)
        print()
        time.sleep(1)
        if self.game_over_reason == "BURNOUT TOTAL! Kamu tidak bisa berpikir jernih lagi.":
            typing_effect("Pikiranmu kacau karena terlalu banyak tekanan.", 0.03)
            typing_effect("Kamu lupa bahwa kesehatan mental sama pentingnya dengan keuangan.", 0.03)
        elif self.game_over_reason == "KELAPARAN! Kamu pingsan karena tidak makan.":
            typing_effect("Kamu mengabaikan kebutuhan dasar tubuhmu.", 0.03)
            typing_effect("Makan adalah investasi terpenting untuk tubuh dan otakmu.", 0.03)
        elif self.game_over_reason == "KRISIS MENTAL! Semua aspek hidupmu hancur.":
            typing_effect("Kamu terlalu fokus pada satu hal dan mengabaikan yang lain.", 0.03)
            typing_effect("Keseimbangan adalah kunci untuk bertahan hidup.", 0.03)
        print()
        time.sleep(1)
        typing_effect("Meskipun bukan akhir yang diharapkan,", 0.03)
        typing_effect("ini adalah awal dari perubahan.", 0.03)
        typing_effect("Jangan menyerah, kamu bisa memperbaiki semuanya.", 0.03)
        print("=" * 60)
        typing_effect("GAME OVER", 0.05)
        print("=" * 60)

    def mulai_game(self):
        clear_screen()
        print("=" * 60)
        typing_effect("🎓 STUDENT LIFE: JOURNEY TO FINANCIAL WISDOM 🎓", 0.05)
        print("=" * 60)
        print()
        typing_effect("📖 PROLOG:", 0.05)
        time.sleep(0.5)
        print()
        typing_effect("Di era digital yang serba cepat ini, banyak remaja yang...", 0.03)
        typing_effect("...kesulitan mengatur keuangan mereka.", 0.03)
        print()
        typing_effect("Tergoda oleh diskon flash sale, FOMO dengan tren terbaru,", 0.03)
        typing_effect("dan tekanan untuk selalu terlihat 'happening' di sosial media.", 0.03)
        print()
        typing_effect("Kamu adalah salah satu dari mereka.", 0.03)
        typing_effect("Seorang siswa SMA yang harus belajar arti kata 'CUKUP'.", 0.03)
        print()
        typing_effect("Ini adalah kisahmu...", 0.04)
        typing_effect("Kisah tentang jatuh bangun belajar mengelola hidup.", 0.04)
        print()
        input("Tekan ENTER untuk memulai perjalanan...")
        self.setup_karakter()
        self.main_loop()

if __name__ == "__main__":
    game = StudentLife()
    game.mulai_game()